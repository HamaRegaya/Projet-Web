<?php
    include_once '../Model/divertissment.php';
    include_once '../Controller/divertissmentC.php';

    $error = "";

    // create adherent
    $genre = null;

    // create an instance of the controller
    $genreC = new genreC();
    if (
        isset($_POST["id_genre"]) &&
		isset($_POST["nom_genre"])
    ) {
        if (
            !empty($_POST["id_genre"]) && 
			!empty($_POST['nom_genre'])
        ) {
            $genre = new genre(
                $_POST['id_genre'],
				$_POST['nom_genre']
            );
            $genreC->ajoutergenre($genre);
            header('Location:afficherdivertissement.php');
        }
        else
            $error = "Missing information";
    }

    
?>
<html >
<head>
  <meta charset="UTF-8">
  <title>Ajouter_genre</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="ajouter/css/style.css">

  
</head>

<body>
<div class="container">
  <div class="card"></div>
  <div class="card">
    <h1 class="title">Ajouter genre</h1>
    <form action="" method="POST">
      <div class="input-container">
        <input type="number" id="id_genre" name="id_genre" required="required"/>
        <label for="#{label}">id genre</label>
        <div class="bar"></div>
      </div>
      <div class="input-container">
        <input type="text" id="nom_genre" name="nom_genre" required="required"/>
        <label for="nom_genre">genre</label>
        <div class="bar"></div>
      </div>
     
      <div class="button-container">
        <button><a href="afficherdivertissement.php">Ajouter</a></button>
      </div>
     
    </form>
  </div>

  </div>

<!-- Portfolio--><a id="portfolio" href="http://andytran.me/" title="View my portfolio!"><i class="fa fa-link"></i></a>
<!-- CodePen--><a id="codepen" href="http://codepen.io/andytran/" title="Follow me!"><i class="fa fa-codepen"></i></a>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="ajouter/js/index.js"></script>

</body>
</html>
