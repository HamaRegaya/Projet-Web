<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- <embed src="abraham_lincoln.pdf" width="1800px" height="10000px" />  -->
    <?php echo'<embed src="livres_pdf/'.$_POST['pdf_livre'].'"  width="1900px" height="10000px">'  ?> 
</body>
</html>