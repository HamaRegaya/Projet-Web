<?php
    include_once '../Model/cours.php';
    include_once '../Controller/coursC.php';

    $error = "";

    // create adherent
    $module = null;

    // create an instance of the controller
    $moduleC = new moduleC();
    if (
        isset($_POST["id_module"]) &&
		isset($_POST["nom_module"])&&
        isset($_POST["image_module"])
    ) {
        if (
            !empty($_POST["id_module"]) && 
			!empty($_POST['nom_module'])&&
            !empty($_POST["image_module"]) 
        ) {
            $module = new module(
                $_POST['id_module'],
				$_POST['nom_module'],
                $_POST["image_module"]
            );
            $moduleC->ajoutermodule($module);

            header('Location:affichercours.php');
        }
        else
            $error = "Missing information";
    }

    
?>
<html >
<head>
  <meta charset="UTF-8">
  <title>Ajouter_module</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="ajouter/css/style.css">

  
</head>

<body>
<div class="container">
  <div class="card"></div>
  <div class="card">
    <h1 class="title">Ajouter module</h1>
    <form action="" method="POST">
      <div class="input-container">
        <input type="number" id="id_module" name="id_module" required="required"/>
        <label for="#{label}">id module</label>
        <div class="bar"></div>
      </div>
      <div class="input-container">
        <input type="text" id="nom_module" name="nom_module" required="required"/>
        <label for="nom_module">module</label>
        <div class="bar"></div>
      </div>
      <div class="button-container">
        <label class="label">  ajouter une image</label>
        <div class="field-body">
          <div class="button-container">
            <label class="upload control">
               upload 
              <input type="file" id="image_module" name="image_module" required="required">
            </label>
            
          </div>
        </div>
      </div><br>
     
      <div class="button-container">
        <button><a href="affichercours.php">Ajouter</a></button>
      </div>
     
    </form>
  </div>

  </div>

<!-- Portfolio--><a id="portfolio" href="http://andytran.me/" title="View my portfolio!"><i class="fa fa-link"></i></a>
<!-- CodePen--><a id="codepen" href="http://codepen.io/andytran/" title="Follow me!"><i class="fa fa-codepen"></i></a>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="ajouter/js/index.js"></script>

</body>
</html>
