<?php
    include_once 'C:\xampp\htdocs\crud_bib\Model\categorie.php';
    include_once 'C:\xampp\htdocs\crud_bib\Controller\categorieC.php';
    $categorieC=new categorieC();
    $listecategorie=$categorieC->affichercategorie(); 
    $error = "";

    // create adherent
    $livre = null;

    // create an instance of the controller
    $livreC = new livreC();
    if (
		isset($_POST["titre_livre"])&&
    isset($_POST["nom_auteur"]) &&
		isset($_POST["date_publication"])&&
    isset($_POST["description_livre"]) &&
		isset($_POST["image_livre"])&&
    isset($_POST["pdf_livre"])&&
    isset($_POST["audio_livre"])&&
    isset($_POST["categorie"])&&
    isset($_POST["QR_code"])
    ) {
        if (
		      	!empty($_POST['titre_livre'])&&
            !empty($_POST["nom_auteur"])&& 
            !empty($_POST["date_publication"]) && 
            !empty($_POST['description_livre'])&&
            !empty($_POST["image_livre"])&& 
            !empty($_POST["pdf_livre"]) && 
            !empty($_POST["audio_livre"]) &&
            !empty($_POST["categorie"])&&
            !empty($_POST["QR_code"])
        ) {
            $livre = new livre(
                $_POST['id_livre'],
				        $_POST['titre_livre'],
                $_POST['nom_auteur'],
				        $_POST['date_publication'],
                $_POST['description_livre'],
				        $_POST['image_livre'],
                $_POST['pdf_livre'],
				        $_POST['audio_livre'],
                $_POST['categorie'],
                $_POST['QR_code']
            );
            $livreC->ajouterlivre($livre);
            header('Location:affichercategorie.php');
        }
        else
            $error = "Missing information";
    }

    
?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Ajouter_livre</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="ajouter/css/style.css">
      <script src="ajouter/js/verif.js"></script>
</head>

<body>
<div class="container">
  <div class="card"></div>
  <div class="card">
    <h1 class="title">Ajouter un livre</h1>
    <form action="" method="POST">
      <div class="input-container">
        <input type="hidden" value="0" id="id_livre" name="id_livre" required="required"/>
      </div>
      <div class="input-container">
        <input type="text" id="titre_livre"name="titre_livre" required="required"onclick="return saisirtitrelivre()"/>
        <label for="titre_livre">Titre</label>
        <div class="bar"></div>
        <p id="errorT" class="error"></p>
      </div>
      <div class="input-container">
        <input type="text" id="nom_auteur"name="nom_auteur" required="required" onclick="return saisirauteur()"/>
        <label for="nom_auteur">Auteur</label>
        <div class="bar"></div>
        <p id="errorA" class="error"></p>
      </div>
      <div class="input-container">
        <input type="date" id="date_publication"name="date_publication" required="required"onclick="return saisirdate_publication()"/>
        <label for="date_publication"></label>
        <div class="bar"></div>
        <p id="errorDP" class="error"></p>
      </div>

      <div class="input-container">
        <input type="text" id="description_livre"name="description_livre"required="required"/>
        <label for="description_livre">description</label>
        <div class="bar"></div>
      </div>
      <div class="button-container">
        <label class="label">  l'image du livre</label>
        <div class="field-body">
          <div class="button-container">
            <label class="upload control">
              <a class="button blue">
                Upload
              </a>
              <input type="file"id="image_livre"name="image_livre">
            </label>
          </div>
        </div>
      </div><br>
      <div class="button-container">
        <label class="label">  Mettre le livre</label>
        <div class="field-body">
          <div class="button-container">
            <label class="upload control">
              <a class="button blue">
                Upload
              </a>
              <input type="file"id="pdf_livre"name="pdf_livre">
            </label>
          </div>
        </div>
      </div><br>
      <div class="button-container">
        <label class="label">  Mettre l'audio</label>
        <div class="field-body">
          <div class="button-container">
            <label class="upload control">
              <a class="button blue">
                Upload
              </a>
              <input type="file"id="audio_livre"name="audio_livre">
            </label>
          </div>
        </div>
      </div><br>
      <div class="button-container">
        <label class="label">  le code_QR</label>
        <div class="field-body">
          <div class="button-container">
            <label class="upload control">
              <a class="button blue">
                Upload
              </a>
              <input type="file"id="QR_code"name="QR_code">
            </label>
          </div>
        </div>
      </div><br>
      <div class="input-container">
<select name="categorie" id="categorie">
  <?php 
  foreach ($listecategorie as $categorie){
  ?>
  <option value="<?php echo $categorie['id_categorie']; ?>"><?php echo $categorie['nom_categorie']; ?></option>
  <?php
  }
  ?>
</select>
<div class="bar"></div>
      </div>

      <div class="button-container">
        <button> <a href="affichercategorie.php">Ajouter</a></button>
      </div>
     
    </form>
  </div>

  </div>

<!-- Portfolio--><a id="portfolio" href="http://andytran.me/" title="View my portfolio!"><i class="fa fa-link"></i></a>
<!-- CodePen--><a id="codepen" href="http://codepen.io/andytran/" title="Follow me!"><i class="fa fa-codepen"></i></a>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="ajouter/js/index.js"></script>

</body>
</html>
