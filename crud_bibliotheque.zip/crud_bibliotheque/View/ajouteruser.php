<?php
    include_once 'C:\xampp\htdocs\crud_bib\Model\user.php';
    include_once 'C:\xampp\htdocs\crud_bib\Controller\userC.php';

    $error = "";

    // create adherent
    $utilisateur = null;

    // create an instance of the controller
    $utilisateurC = new utilisateurC();
    if (
        isset($_POST["id_user"]) &&
		isset($_POST["nom_user"])&&
        isset($_POST["prenom_user"]) &&
		isset($_POST["email_user"])&&
        isset($_POST["mdp_user"]) &&
		isset($_POST["date_de_naissance"])&&
        isset($_POST["fonction"])
    ) {
        if (
            !empty($_POST["id_user"]) && 
		    !empty($_POST['nom_user'])&&
            !empty($_POST["prenom_user"])&& 
            !empty($_POST["email_user"]) && 
            !empty($_POST['mdp_user'])&&
            !empty($_POST["date_de_naissance"])&& 
            !empty($_POST["fonction"])
        ) {
            $utilisateur = new utilisateur(
                $_POST['id_user'],
				$_POST['nom_user'],
                $_POST['prenom_user'],
				$_POST['email_user'],
                $_POST['mdp_user'],
				$_POST['date_de_naissance'],
                $_POST['fonction']
            );
            $utilisateurC->ajouteruser($utilisateur);
            header('Location:afficheruser.php');
        }
        else
            $error = "Missing information";
    }

    
?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Ajouter_user</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="ajouter/css/style.css">

  
</head>

<body>
<div class="container">
  <div class="card"></div>
  <div class="card">
    <h1 class="title">Ajouter un utilisateur</h1>
    <form action="" method="POST">
      <div class="input-container">
        <input type="number" id="id_user" name="id_user"required="required"/>
        <label for="id_user">id user</label>
        <div class="bar"></div>
      </div>
      <div class="input-container">
        <input type="text" id="nom_user"name="nom_user" required="required"/>
        <label for="nom_user">Nom</label>
        <div class="bar"></div>
      </div>
      <div class="input-container">
        <input type="text" id="prenom_user"name="prenom_user"required="required"/>
        <label for="prenom_user">Prenom</label>
        <div class="bar"></div>
      </div>
      <div class="input-container">
        <input type="email" id="email_user"name="email_user" required="required"/>
        <label for="email_user">Email</label>
        <div class="bar"></div>
      </div>

      <div class="input-container">
        <input type="password" id="mdp_user"name="mdp_user"required="required"/>
        <label for="mdp_user">Mot de passe</label>
        <div class="bar"></div>
      </div>
      <div class="input-container">
        <input type="date" id="date_de_naissance"name="date_de_naissance"required="required"/>
        <label for="date_de_naissance"></label>
        <p>Date de naissance</p>
        <div class="bar"></div>
      </div>
      <div class="input-container">
        <input type="number" id="fonction"name="fonction"required="required"/>
        <label for="fonction">Fonction</label>
        <p>Tapez 0:admin | Tapez 1:etudiant</p>
        <div class="bar"></div>
      </div>
      <div class="button-container">
        <button> <a href="afficheruser.php">Ajouter</a></button>
      </div>
     
    </form>

  </div>

  </div>

<!-- Portfolio--><a id="portfolio" href="http://andytran.me/" title="View my portfolio!"><i class="fa fa-link"></i></a>
<!-- CodePen--><a id="codepen" href="http://codepen.io/andytran/" title="Follow me!"><i class="fa fa-codepen"></i></a>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="ajouter/js/index.js"></script>

</body>
</html>
