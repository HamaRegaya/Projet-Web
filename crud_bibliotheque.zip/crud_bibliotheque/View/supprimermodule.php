<?php
	include '../Controller/coursC.php';
	$moduleC=new moduleC();
	$moduleC->supprimermodule($_GET["id_module"]);
	header('Location:affichercours.php');
?>