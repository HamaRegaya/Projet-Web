<?php
	include '../Controller/userC.php';
	$utilisateurC=new utilisateurC();
	$utilisateurC->supprimeruser($_GET["id_user"]);
	header('Location:afficheruser.php');
?>