<?php
	include '../Controller/divertissmentC.php';
	$genreC=new genreC();
	$genreC->supprimergenre($_GET["id_genre"]);
	header('Location:afficherdivertissement.php');
?>