<?php
    include_once '../Model/categorie.php';
    include_once '../Controller/categorieC.php';

    $error = "";

    // create adherent
    $categorie = null;

    // create an instance of the controller
    $categorieC = new categorieC();
    if (
        // isset($_POST["id_categorie"]) &&
		isset($_POST["nom_categorie"])&&
        isset($_POST["image_categorie"])
    ) {
        if (
            // !empty($_POST["id_categorie"]) && 
			!empty($_POST['nom_categorie'])&&
            !empty($_POST["image_categorie"]) 
        ) {
            $categorie = new categorie(
                $_POST['id_categorie'],
				$_POST['nom_categorie'],
                $_POST["image_categorie"]
            );
            $categorieC->ajoutercategorie($categorie);
            header('Location:affichercategorie.php');
        }
        else
            $error = "Missing information";
    }

    
?>
<html >
<head>
  <meta charset="UTF-8">
  <title>Ajouter_catégorie</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="ajouter/css/style.css">
      <script src="ajouter/js/verif.js"></script>

  
</head>

<body>
<div class="container">
  <div class="card"></div>
  <div class="card">
    <h1 class="title">Ajouter Catégorie</h1>
    <form action="" method="POST" onsubmit= "return ajouter(event)">
      <div class="input-container">
        <input type="hidden" id="id_categorie" name="id_categorie" required="required" value="0"/>
        <!-- <label for="#{label}">id Catégorie</label> -->
        <!-- <div class="bar"></div> -->
      </div>
      <div class="input-container">
        <input type="text" id="nom_categorie" name="nom_categorie" required="required"onclick="return verif()"/>
        <label for="nom_categorie"  >catégorie</label>
        <div class="bar"></div>
        <p id="errorC" class="error"></p>
      </div>
      <div class="button-container">
        <label class="label">  ajouter une image</label>
        <div class="field-body">
          <div class="button-container">
            <label class="upload control">
               upload 
              <input type="file" id="image_categorie" name="image_categorie" required="required">
            </label>
            
          </div>
        </div>
      </div><br>
     
      <div class="button-container">
        <button><a href="affichercategorie.php">Ajouter</a></button>
      </div>
     
    </form>
  </div>

  </div>

<!-- Portfolio--><a id="portfolio" href="http://andytran.me/" title="View my portfolio!"><i class="fa fa-link"></i></a>
<!-- CodePen--><a id="codepen" href="http://codepen.io/andytran/" title="Follow me!"><i class="fa fa-codepen"></i></a>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="ajouter/js/index.js"></script>

</body>
</html>
