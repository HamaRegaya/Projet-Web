function verif(){

    var categorie=document.getElementById("nom_categorie").value;
    var regex = /^[A-Za-z]+$/;


    if (!(regex.test(categorie))) {
        document.getElementById("errorC").textContent = "Name has to be composed of letters only!";
        document.getElementById("errorC").style.color = "red";
        return 0;
    } else if (categorie[0] == categorie[0].toLowerCase()) {
        document.getElementById("errorC").textContent = "Name has to start by a capital letter!";
        document.getElementById("errorC").style.color = "red";
        return 0;
    } else {
        document.getElementById("errorC").textContent = "Category Verified";
        document.getElementById("errorC").style.color = "green";
        return 1;
    }
  }
  function saisirtitrelivre(){

    var livre=document.getElementById("titre_livre").value;


 if (livre[0] == livre[0].toLowerCase()) {
        document.getElementById("errorT").textContent = "Title has to start by a capital letter!";
        document.getElementById("errorT").style.color = "red";
        return 0;
    } else {
        document.getElementById("errorT").textContent = "Title Verified";
        document.getElementById("errorT").style.color = "green";
        return 1;
    }
  }
  function saisirauteur(){

    var livre=document.getElementById("nom_auteur").value;


 if (livre[0] == livre[0].toLowerCase()) {
        document.getElementById("errorA").textContent = "Name has to start by a capital letter!";
        document.getElementById("errorA").style.color = "red";
        return 0;
    } else {
        document.getElementById("errorA").textContent = "Auteur Verified";
        document.getElementById("errorA").style.color = "green";
        return 1;
    }
  }
  function saisirdate_publication() {
    var DateFond = document.getElementById('date_publication').value;
    var dat=new Date();

    if (new Date(DateFond).getTime() >= dat.getTime())
    {
        document.getElementById("errorDP").textContent = "date superiour";
        document.getElementById("errorDP").style.color = "red";
        return 0;
    }
    else
    {
        document.getElementById("errorDP").textContent = "date verified";
        document.getElementById("errorDP").style.color="green";
        return 1;
    }
}
  
  function ajouter(event) {
    if (verif() == 0 )
        event.preventDefault();
}