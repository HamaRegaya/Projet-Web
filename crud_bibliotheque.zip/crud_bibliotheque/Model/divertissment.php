<?php
	class genre{
		private $id_genre=null;
		private $nom_genre=null;
		function __construct($id_genre, $nom_genre){
            $this->id_genre=$id_genre;
			$this->nom_genre=$nom_genre;
		}
		function getid_genre(){
			return $this->id_genre;
		}
		function getnom_genre(){
			return $this->nom_genre;
		}
        function setid_genre(string $id_genre){
			$this->id_genre=$id_genre;
		}
        function setnom_genre(string $nom_genre){
			$this->nom_genre=$nom_genre;
		}
		
	}
    ?>