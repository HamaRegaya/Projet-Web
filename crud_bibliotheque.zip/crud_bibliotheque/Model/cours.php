<?php
	class module{
		private $id_module=null;
		private $nom_module=null;
        private $image_module=null;
		function __construct($id_module, $nom_module,$image_module){
            $this->id_module=$id_module;
			$this->nom_module=$nom_module;
            $this->image_module=$image_module;
		}
		function getid_module(){
			return $this->id_module;
		}
		function getnom_module(){
			return $this->nom_module;
		}
        function getimage_module(){
			return $this->image_module;
		}
        function setid_module(string $id_module){
			$this->id_module=$id_module;
		}
        function setnom_module(string $nom_module){
			$this->nom_module=$nom_module;
		}
        function setimage_module(string $image_module){
			$this->image_module=$image_module;
		}
		
	}


?>