<?php
class utilisateur{
    private $id_user=null;
    private $nom_user=null;
    private $prenom_user=null;
    private $email_user=null;
    private $mdp_user=null;
    private $date_de_naissance=null;
    private $fonction=null;
    function __construct($id_user,$nom_user,$prenom_user,$email_user,$mdp_user,$date_de_naissance,$fonction){
        $this->id_user=$id_user;
        $this->nom_user=$nom_user;
        $this->prenom_user=$prenom_user;
        $this->email_user=$email_user;
        $this->mdp_user=$mdp_user;
        $this->date_de_naissance=$date_de_naissance;
        $this->fonction=$fonction;
    }
    function getid_user(){
        return $this->id_user;
    }
    function getnom_user(){
        return $this->nom_user;
    }
    function getprenom_user(){
        return $this->prenom_user;
    }
    function getemail_user(){
        return $this->email_user;
    }
    function getmdp_user(){
        return $this->mdp_user;
    }
    function getdate_user(){
        return $this->date_de_naissance;
    }
    function getfonction_user(){
        return $this->fonction;
    }

    function setid_user(string $id_user){
        $this->id_user=$id_user;
    }
    function setnom_user(string $nom_user){
        $this->nom_user=$nom_user;
    }
    function setprenom_user(string $prenom_user){
        $this->prenom_user=$prenom_user;
    }
    function setemail_user(string $email_user){
        $this->email_user=$email_user;
    }
    function setmdp_user(string $mdp_user){
        $this->mdp_user=$mdp_user;
    }
    function setdate_user(string $date_de_naissance){
        $this->date_de_naissance=$date_de_naissance;
    }
    function setfonction_user(string $fonction){
        $this->fonction=$fonction;
    }


    
}

?>