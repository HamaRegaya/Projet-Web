<?php
include 'C:\xampp\htdocs\crud_bib\config.php';
include_once 'C:\xampp\htdocs\crud_bib\Model\divertissment.php';
class genreC {
    function affichergenre(){
        $sql="SELECT * FROM genre";
        $db = config::getConnexion();
        try{
            $liste = $db->query($sql);
            return $liste;
        }
        catch(Exception $e){
            die('Erreur:'. $e->getMeesage());
        }
    }
    function supprimergenre($id_genre){
        $sql="DELETE FROM genre WHERE id_genre=:id_genre";
        $db = config::getConnexion();
        $req=$db->prepare($sql);
        $req->bindValue(':id_genre', $id_genre);
        try{
            $req->execute();
        }
        catch(Exception $e){
            die('Erreur:'. $e->getMessage());
        }
    }
    function ajoutergenre($genre){
        $sql="INSERT INTO genre (id_genre, nom_genre) 
        VALUES (:id_genre,:nom_genre)";
        $db = config::getConnexion();
        try{
            $query = $db->prepare($sql);
            $query->execute([
                'id_genre' => $genre->getid_genre(),
                'nom_genre' => $genre->getnom_genre()
            ]);			
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }			
    }
    function recuperergenre($id_genre){
        $sql="SELECT * from genre where id_genre=$id_genre";
        $db = config::getConnexion();
        try{
            $query=$db->prepare($sql);
            $query->execute();

            $genre=$query->fetch();
            return $genre;
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }
    
    function modifiergenre($genre, $id_genre){
        try {
            $db = config::getConnexion();
            $query = $db->prepare(
                'UPDATE genre SET 
                    nom_genre= :nom_genre
                WHERE id_genre= :id_genre'
            );
            $query->execute([
                'nom_genre' => $genre->getnom_genre(),
                'id_genre' => $id_genre
            ]);
            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }

}
?>