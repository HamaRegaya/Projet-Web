<?php
	include 'C:\xampp\htdocs\crud_bib\config.php';
	include_once 'C:\xampp\htdocs\crud_bib\Model\user.php';
    class utilisateurC {
		function afficheruser(){
			$sql="SELECT * FROM utilisateur";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function supprimeruser($id_user){
			$sql="DELETE FROM utilisateur WHERE id_user=:id_user";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':id_user', $id_user);
			try{
				$req->execute();
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
		}
		function ajouteruser($utilisateur){
			$sql="INSERT INTO utilisateur (id_user,nom_user ,prenom_user,email_user,mdp_user,date_de_naissance,fonction) 
			VALUES (:id_user,:nom_user ,:prenom_user,:email_user,:mdp_user,:date_de_naissance,:fonction)";
			$db = config::getConnexion();
			try{
				$query = $db->prepare($sql);
				$query->execute([
					'id_user' => $utilisateur->getid_user(),
					'nom_user'=> $utilisateur->getnom_user(),
					'prenom_user' => $utilisateur->getprenom_user(),
					'email_user'=>$utilisateur->getemail_user(),
					'mdp_user'=>$utilisateur->getmdp_user(),
					'date_de_naissance'=> $utilisateur->getdate_user(),
					'fonction'=> $utilisateur->getfonction_user()
					
				]);			
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}			
		}
		function recupereruser($id_user){
			$sql="SELECT * from utilisateur where id_user=$id_user";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$utilisateur=$query->fetch();
				return $utilisateur;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		
		function modifieruser($utilisateur, $id_user){
			try {
				$db = config::getConnexion();
				$query = $db->prepare(
					'UPDATE utilisateur SET 
					    nom_user= :nom_user,
						prenom_user= :prenom_user,
						email_user=:email_user,
						mdp_user=:mdp_user,
						date_de_naissance=:date_de_naissance,
						fonction=:fonction

					WHERE id_user= :id_user'
				);
				$query->execute([
					'nom_user'=> $utilisateur->getnom_user(),
					'prenom_user' => $utilisateur->getprenom_user(),
					'email_user'=>$utilisateur->getemail_user(),
					'mdp_user'=>$utilisateur->getmdp_user(),
					'date_de_naissance'=> $utilisateur->getdate_user(),
					'fonction'=> $utilisateur->getfonction_user(),
					'id_user' => $id_user
				]);
				echo $query->rowCount() . " records UPDATED successfully <br>";
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}

	}   
    
    
    
?>