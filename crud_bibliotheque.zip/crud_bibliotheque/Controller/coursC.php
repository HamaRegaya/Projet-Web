<?php
	include 'C:\xampp\htdocs\crud_bib\config.php';
	include_once 'C:\xampp\htdocs\crud_bib\Model\cours.php';
	class moduleC {
		function affichermodule(){
			$sql="SELECT * FROM module";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function supprimermodule($id_module){
			$sql="DELETE FROM module WHERE id_module=:id_module";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':id_module', $id_module);
			try{
				$req->execute();
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
		}
		function ajoutermodule($module){
			$sql="INSERT INTO module (id_module, nom_module,image_module ) 
			VALUES (:id_module,:nom_module,:image_module)";
			$db = config::getConnexion();
			try{
				$query = $db->prepare($sql);
				$query->execute([
					'id_module' => $module->getid_module(),
					'nom_module' => $module->getnom_module(),
					'image_module'=> $module->getimage_module()
				]);			
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}			
		}
		function recuperermodule($id_module){
			$sql="SELECT * from module where id_module=$id_module";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$module=$query->fetch();
				return $module;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		
		function modifiermodule($module, $id_module){
			try {
				$db = config::getConnexion();
				$query = $db->prepare(
					'UPDATE module SET 
						nom_module= :nom_module,
						image_module=:image_module

					WHERE id_module= :id_module'
				);
				$query->execute([
					'nom_module' => $module->getnom_module(),
					'image_module'=>$module->getimage_module(),
					'id_module' => $id_module
				]);
				echo $query->rowCount() . " records UPDATED successfully <br>";
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}

	}
?>