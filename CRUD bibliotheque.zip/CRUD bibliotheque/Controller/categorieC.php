<?php
	include 'C:\xampp\htdocs\crud_bib\config.php';
	include_once 'C:\xampp\htdocs\crud_bib\Model\categorie.php';
	class categorieC {
		function affichercategorie(){
			$sql="SELECT * FROM categorie";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function supprimercategorie($id_categorie){
			$sql="DELETE FROM categorie WHERE id_categorie=:id_categorie";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':id_categorie', $id_categorie);
			try{
				$req->execute();
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
		}
		function ajoutercategorie($categorie){
			$sql="INSERT INTO categorie (id_categorie, nom_categorie,image_categorie ) 
			VALUES (:id_categorie,:nom_categorie,:image_categorie)";
			$db = config::getConnexion();
			try{
				$query = $db->prepare($sql);
				$query->execute([
					'id_categorie' => $categorie->getid_categorie(),
					'nom_categorie' => $categorie->getnom_categorie(),
					'image_categorie'=> $categorie->getimage_categorie()
				]);			
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}			
		}
		function recuperercategorie($id_categorie){
			$sql="SELECT * from categorie where id_categorie=$id_categorie";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$categorie=$query->fetch();
				return $categorie;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		
		function modifiercategorie($categorie, $id_categorie){
			try {
				$db = config::getConnexion();
				$query = $db->prepare(
					'UPDATE categorie SET 
						nom_categorie= :nom_categorie,
						image_categorie=:image_categorie

					WHERE id_categorie= :id_categorie'
				);
				$query->execute([
					'nom_categorie' => $categorie->getnom_categorie(),
					'image_categorie'=>$categorie->getimage_categorie(),
					'id_categorie' => $id_categorie
				]);
				echo $query->rowCount() . " records UPDATED successfully <br>";
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}

	}
	class livreC {
		function afficherlivre(){
			$sql="SELECT * FROM livre";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMeesage());
			}
		}
		function supprimerlivre($id_livre){
			$sql="DELETE FROM livre WHERE id_livre=:id_livre";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':id_livre', $id_livre);
			try{
				$req->execute();
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
		}
		function ajouterlivre($livre){
			$sql="INSERT INTO livre (id_livre,titre_livre ,nom_auteur,date_publication,description_livre,image_livre,pdf_livre,audio_livre ) 
			VALUES (:id_livre,:titre_livre ,:nom_auteur,:date_publication,:description_livre,:image_livre,:pdf_livre,:audio_livre)";
			$db = config::getConnexion();
			try{
				$query = $db->prepare($sql);
				$query->execute([
					'id_livre' => $livre->getid_livre(),
					'titre_livre'=> $livre->gettitre_livre(),
					'nom_auteur' => $livre->getnom_auteur(),
					'date_publication'=>$livre->getdate_publication(),
					'description_livre'=>$livre->getdescription_livre(),
					'image_livre'=> $livre->getimage_livre(),
					'pdf_livre'=> $livre->getpdf_livre(),
					'audio_livre'=>$livre->getaudio_livre()
					
				]);			
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}			
		}
		function recupererlivre($id_livre){
			$sql="SELECT * from livre where id_livre=$id_livre";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();

				$livre=$query->fetch();
				return $livre;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		
		function modifierlivre($livre, $id_livre){
			try {
				$db = config::getConnexion();
				$query = $db->prepare(
					'UPDATE livre SET 
					    titre_livre= :titre_livre,
						nom_auteur= :nom_auteur,
						date_publication=:date_publication,
						description_livre=:description_livre,
						image_livre=:image_livre,
						pdf_livre=:pdf_livre,
						audio_livre=:audio_livre

					WHERE id_livre= :id_livre'
				);
				$query->execute([
					'nom_auteur' => $livre->getnom_auteur(),
					'titre_livre'=> $livre->gettitre_livre(),
					'date_publication'=>$livre->getdate_publication(),
					'description_livre'=>$livre->getdescription_livre(),
					'image_livre'=> $livre->getimage_livre(),
					'pdf_livre'=> $livre->getpdf_livre(),
					'audio_livre'=>$livre->getaudio_livre(),
					'id_livre' => $id_livre
				]);
				echo $query->rowCount() . " records UPDATED successfully <br>";
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}

	}
?>