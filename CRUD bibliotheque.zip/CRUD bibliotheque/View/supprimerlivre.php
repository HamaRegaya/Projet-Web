<?php
	include '../Controller/categorieC.php';
	$livreC=new livreC();
	$livreC->supprimerlivre($_GET["id_livre"]);
	header('Location:affichercategorie.php');
?>