function verif(){

    var categorie=document.getElementById("nom_categorie").value;
    var regex = /^[A-Za-z]+$/;


    if (!(regex.test(categorie))) {
        document.getElementById("errorC").textContent = "Name has to be composed of letters only!";
        document.getElementById("errorC").style.color = "red";
        return 0;
    } else if (categorie[0] == categorie[0].toLowerCase()) {
        document.getElementById("errorC").textContent = "Name has to start by a capital letter!";
        document.getElementById("errorC").style.color = "red";
        return 0;
    } else {
        document.getElementById("errorC").textContent = "Category Verified";
        document.getElementById("errorC").style.color = "green";
        return 1;
    }
  }
  
  function ajouter(event) {
    if (verif() == 0 )
        event.preventDefault();
}